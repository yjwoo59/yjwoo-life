---
date: 2026-04-24
ai_model: Claude Opus 4.7
topic: 하네스 오케스트레이터 설계
category: 개발-방법론
tags: [하네스, 오케스트레이터, CLAUDE.md, Mermaid, Obsidian, Claude Code]
importance: high
---

# 하네스 오케스트레이터 설계 — 대화 로그

## 📌 대화 요약

1. **주제 시작**: "FDAI 하네스 260424" (FDAI 프로젝트는 이름만 있고 내용 미정)
2. **하네스 개념 확인**: 큰 폴더 안에 전체를 담되, 실행 시 필요 파일만 읽힘. 오케스트레이터 + 계층적 서브에이전트 구조.
3. **오케스트레이터 툴 논의**: Claude Code 수동(CLAUDE.md) → MCP → Semantic Kernel (C#) 단계적 접근 제안
4. **시각화 요구**: 사용자는 md 읽기보다 차트로 보길 원함 → **Mermaid 블록** 도입 결정
5. **파일 구조 결정**: 단일 CLAUDE.md → **분리 파일 구조**로 전환 (최상위 + docs/ 5개)
6. **결과물 생성**: CLAUDE.md + docs/01~05 총 6개 파일

---

## 🎯 주요 결론

### 1. 하네스 5개 레버 (재확인)
- Rules, Tools, Skills, Memory, Feedback Loop

### 2. 오케스트레이터 설계 원칙
- **"판단하지 않는다. 규칙대로 라우팅한다."**
- 명시적 분기 조건 필수
- 불명확 시 반드시 질문

### 3. 3계층 구조
```
최상위 CLAUDE.md (오케스트레이터)
├── Dev Agent (C# 개발)
├── Life PM Agent (프로젝트·인생)
└── Archive Agent (70TB 자료)
```

### 4. 툴 스택 (단계별)
| 단계 | 툴 | 시점 |
|---|---|---|
| 1 | CLAUDE.md 파일 계층 | 지금 |
| 2 | MCP 서버 | 1개월 후 |
| 3 | Semantic Kernel (C#) | 필요 시 |

### 5. 시각화 전략
- **Mermaid**를 md 안에 삽입 → Obsidian에서 자동 렌더링
- 사용 다이어그램: `graph`, `flowchart`, `sequenceDiagram`, `gantt`, `mindmap`
- Claude는 텍스트로 쓰고, 사용자는 차트로 본다

### 6. 파일 분리 구조
- 최상위 CLAUDE.md는 **목차 + 핵심만** (짧게)
- 각 섹션은 `docs/` 하위 별도 파일
- 이유: 컨텍스트 절약 + 직관적 네비게이션 + Obsidian 그래프뷰

---

## 📂 생성된 결과물

```
harness-root/
├── CLAUDE.md                    ← 최상위 진입점 (짧은 목차)
└── docs/
    ├── 01-structure.md          ← 🗺️ 전체 구조
    ├── 02-routing.md            ← 🔀 작업 분기 규칙
    ├── 03-rules.md              ← 🔒 절대 규칙
    ├── 04-feedback-loop.md      ← 🔁 검증 절차
    └── 05-roadmap.md            ← 🚀 로드맵
```

---

## ✅ 액션 아이템

- [ ] **FDAI 정체 확정** — 무엇의 약자인지, 어떤 프로젝트인지 설명 필요
- [ ] `shared/ABOUT-ME.md` 작성 (다음 단계)
- [ ] `agents/dev/CLAUDE.md` 작성 (Phase 2)
- [ ] `agents/life/CLAUDE.md` 작성 (Phase 2)
- [ ] `agents/archive/CLAUDE.md` 작성 (Phase 2)
- [ ] Obsidian에서 열어 Mermaid 렌더링 확인
- [ ] 실제 C# 프로젝트에 적용 테스트

---

## ❓ 미해결 질문

1. **FDAI가 무엇인가?** — 제목에만 등장, 내용 미정
2. **Obsidian vault**를 하네스 루트와 동일하게 둘지, 별도로 둘지?
3. **Git 저장소**는 언제부터 시작할지?
4. **ABOUT-ME.md** 에 담을 정체성 범위 어디까지?

---

## 🔗 관련 대화

- 2026-04-23: 하네스 엔지니어링 개념 학습
- 2026-04-23: 40년 자료 정리 PM 논의
- 2026-04-23: Obsidian vs Notion 비교

---

## 💡 다음 세션 제안

다음 세션에서 이어갈 수 있는 선택지:

1. **ABOUT-ME.md 작성** — 사용자 정체성 파일 (하네스 심장부)
2. **agents/dev/CLAUDE.md 작성** — 기존 C# 프로젝트 규칙 통합
3. **FDAI 정의** — 프로젝트 설명 받아 `agents/life/projects/fdai/` 구축
4. **실제 C# 프로젝트에 적용 테스트** — 파일 배치 후 Claude Code 실행

---

## 📝 전체 대화 원본 (요약)

> **User**: FDAI 하네스 260424
> **Claude**: FDAI가 무엇인지 질문

> **User**: 하네스는 현재·미래·인생 프로젝트를 하나로 정리하는 데 유용. 큰 폴더지만 매번 필요한 정보만 읽고 계층 서브에이전트 관리 가능한가?
> **Claude**: 맞음. 단, Claude Code는 자동 계층 분기 안 함. CLAUDE.md에 명시적 분기 규칙 필요.

> **User**: 에이전트 오케스트레이터 지원 툴 있나?
> **Claude**: Claude Code 수동 → MCP → Semantic Kernel 단계 제안. C# 개발자에게는 Semantic Kernel 적합.

> **User**: (Obsidian vs Notion 비교 내용 제시)
> **Claude**: 어제 대화 내용임을 확인, 의도 재확인

> **User**: 오케스트레이터 설계 제안 요청
> **Claude**: 3계층 구조 + 3단계 툴 전환 로드맵 + 4주 시작 계획 제시

> **User**: CLAUDE.md가 공유 매개체지만 나는 md보다 차트·간트·마인드맵 선호. 시각화 개념 아는가?
> **Claude**: 네. Mermaid를 md 안에 넣으면 Obsidian에서 자동 차트 렌더링. 예시 제시.

> **User**: 단일 CLAUDE.md 생성 승인
> **Claude**: 5개 Mermaid 포함 단일 파일 생성

> **User**: 🗺️ 전체 구조를 클릭하면 내용 열리게 하는 방법?
> **Claude**: 3가지 방법 제시 — details 접기, 파일 분리, Obsidian 임베드. 추천: 파일 분리 + details 하이브리드.

> **User**: FDAI 미설명 확인. 파일 분리 구조로 재작성. 대화 로그도 파일로.
> **Claude**: (현재 응답) — 6개 파일 + 대화 로그 생성.

---

**저장 위치**: `shared/conversations/2026/04/2026-04-24-harness-orchestrator.md` 권장
