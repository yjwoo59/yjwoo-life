# 🗺️ 01. 전체 구조

> 하네스의 폴더·에이전트 전체 지도.
> **돌아가기**: [← CLAUDE.md](../CLAUDE.md)

---

## 계층 트리

```mermaid
graph TD
    Root[CLAUDE.md<br/>오케스트레이터]
    Root --> Dev[agents/dev<br/>🔧 개발 에이전트]
    Root --> Life[agents/life<br/>📋 인생 PM 에이전트]
    Root --> Archive[agents/archive<br/>📦 아카이브 에이전트]
    Root --> Shared[shared/<br/>🤝 공통 컨텍스트]

    Dev --> DevDocs[docs/시방서.md<br/>docs/dev.md]
    Dev --> DevSkills[skills/<br/>작업별 절차]

    Life --> LifeProj[projects/<br/>FDAI 등]
    Life --> LifeAreas[areas/<br/>가족, 건강, 재무]

    Archive --> Cold[Cold Archive<br/>NAS·외장하드 70TB]
    Archive --> AISearch[AI 검색 레이어]

    Shared --> About[ABOUT-ME.md]
    Shared --> Decisions[decisions/<br/>ADR]

    style Root fill:#ffd700
    style Shared fill:#e0e0e0
    style Dev fill:#b3d9ff
    style Life fill:#ffcccc
    style Archive fill:#ccffcc
```

---

## 폴더 구조 (텍스트)

```
harness-root/
├── CLAUDE.md                    ← 오케스트레이터 (진입점)
│
├── docs/                        ← 오케스트레이터 문서
│   ├── 01-structure.md          ← 이 파일
│   ├── 02-routing.md
│   ├── 03-rules.md
│   ├── 04-feedback-loop.md
│   └── 05-roadmap.md
│
├── shared/                      ← 모든 에이전트 공유
│   ├── ABOUT-ME.md              ← 사용자 정체성
│   ├── decisions/               ← 주요 결정 (ADR)
│   └── proposals/               ← 변경 제안
│
├── agents/
│   ├── dev/
│   │   ├── CLAUDE.md            ← 개발 에이전트 규칙
│   │   ├── skills/              ← 작업별 절차
│   │   └── projects/
│   │
│   ├── life/
│   │   ├── CLAUDE.md            ← 인생 PM 에이전트 규칙
│   │   ├── projects/            ← FDAI (상세 미정) 등
│   │   └── areas/               ← 가족/건강/재무
│   │
│   └── archive/
│       ├── CLAUDE.md            ← 아카이브 에이전트 규칙
│       └── inventory/           ← 자료 목록
│
├── src/                         ← C# 코드
├── tests/                       ← 테스트
└── inbox/                       ← 날것 입력 (폰에서)
```

---

## 에이전트별 역할

| 에이전트 | 담당 | 주요 파일 |
|---|---|---|
| **🔧 Dev** | C# 코드 작성·수정·테스트·빌드 | `src/`, `tests/`, `docs/시방서.md`, `docs/dev.md` |
| **📋 Life PM** | 프로젝트 관리, 일정, 인생 결정 | `agents/life/projects/`, `agents/life/areas/` |
| **📦 Archive** | 70TB 자료 정리, 백업, 검색 | `agents/archive/inventory/` |

---

## ❓ 미정 항목

- **FDAI**: 이름만 있음. 설명 추가 후 `agents/life/projects/fdai/` 생성 예정

---

## 관련 문서

- [🔀 02. 작업 분기 규칙](./02-routing.md)
- [🔒 03. 절대 규칙](./03-rules.md)
